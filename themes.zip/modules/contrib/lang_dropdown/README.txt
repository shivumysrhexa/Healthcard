  ------------------------------------------------------------------------------------
                                      INSTALLATION
  ------------------------------------------------------------------------------------

  This module requires optional core module: "Language".
  The module will populate a new block named "Language dropdown switcher" under "/admin/structure/block".
  
  Please see the below instructions to configure the block.

  ------------------------------------------------------------------------------------
                                      CONFIGURATION
  ------------------------------------------------------------------------------------

  1) Configure the "Language negotiation" at "/admin/config/regional/language/detection".
     
  2) Place the "Language dropdown switcher" block at "/admin/structure/block".
  
  3) Configure the "Language dropdown switcher" block settings as follows.
