<?php

namespace Drupal\ms_ajax_form_example\Step;

use Drupal\ms_ajax_form_example\Button\StepOneNextButton;
use Drupal\ms_ajax_form_example\Validator\ValidatorRequired;

/**
 * Class StepOne.
 *
 * @package Drupal\ms_ajax_form_example\Step
 */
class StepOne extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_ONE;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepOneNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements() {
    /*$form['name'] = [
      '#type' => 'textfield',
      '#title' => t("What's your name?"),
      '#required' => FALSE,
      '#default_value' => isset($this->getValues()['name']) ? $this->getValues()['name'] : NULL,
    ];

     $form['candidate_country'] = array (
      '#type' => 'select',
      '#title' => ('Country'),
      '#options' => array(
        'IN' => t('INDIA'),
        'US' => t('AMERICA'),
      ),
    );*/

    # an html radio button widget for a drupal form

    # the options to display in our form radio buttons
    $options = array(
     /* 'punt' => t('Punt'),
      'field_goal' => t('Kick field goal'), */
      'run' => t('Run'),
      'pass' => t('Pass'),
    );

    $options1 = array(
     /* 'punt' => t('Punt'),
      'field_goal' => t('Kick field goal'), */
      'yes' => t('Yes'),
      'no' => t('No'),
    );

    $form['fourth_down'] = array(
      '#type' => 'radios',
      '#title' => ('1. What would you like to do on fourth down?'),
      '#options' => $options,
      '#description' => ('What would you like to do on fourth down?'),
    );


    $form['fourth_down1'] = array(
      '#type' => 'radios',
      '#title' => ('2. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );

    $form['fourth_down2'] = array(
      '#type' => 'radios',
      '#title' => ('3. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );

    $form['fourth_down3'] = array(
      '#type' => 'radios',
      '#title' => ('4. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );

    $form['fourth_down4'] = array(
      '#type' => 'radios',
      '#title' => ('5. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );

    $form['fourth_down5'] = array(
      '#type' => 'radios',
      '#title' => ('6. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );
     $form['fourth_down5'] = array(
      '#type' => 'radios',
      '#title' => ('7. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('8 What would you like to do on fourth down?'),
    );
      $form['fourth_down6'] = array(
      '#type' => 'radios',
      '#title' => ('8. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );
       $form['fourth_down7'] = array(
      '#type' => 'radios',
      '#title' => ('10. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );
        $form['fourth_down8'] = array(
      '#type' => 'radios',
      '#title' => ('11. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );
    $form['fourth_down9'] = array(
      '#type' => 'radios',
      '#title' => ('12. What would you like to do on fourth down?'),
      '#options' => $options1,
      '#description' => ('What would you like to do on fourth down?'),
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldNames() {
    return [
      'name',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    return [
      'name' => [
        new ValidatorRequired("Hey stranger, please tell me your name. I would like to get to know you."),
      ],
    ];
  }

}
