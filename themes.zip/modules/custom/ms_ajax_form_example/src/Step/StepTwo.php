<?php

namespace Drupal\ms_ajax_form_example\Step;

use Drupal\ms_ajax_form_example\Button\StepTwoNextButton;
use Drupal\ms_ajax_form_example\Button\StepTwoPreviousButton;
use Drupal\ms_ajax_form_example\Validator\ValidatorRequired;

/**
 * Class StepTwo.
 *
 * @package Drupal\ms_ajax_form_example\Step
 */
class StepTwo extends BaseStep {

  /**
   * {@inheritdoc}
   */
  protected function setStep() {
    return StepsEnum::STEP_TWO;
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    return [
      new StepTwoPreviousButton(),
      new StepTwoNextButton(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildStepFormElements() {
    $form['interests'] = [
      '#type' => 'checkboxes',
      '#title' => t('1. Nice to meet you! So, what are you interests?'),
      '#options' => [1 => 'interest 1', 2 => 'interest 2', 3 => 'interest 3'],
      '#default_value' => isset($this->getValues()['interests']) ? $this->getValues()['interests'] : [],
      '#required' => FALSE,
    ];
   

$form['interests2'] = [
      '#type' => 'radios',
      '#title' => t('2. Nice to meet you! So, what are you interests?'),
      '#options' => [1 => 'interest 1', 2 => 'interest 2', 3 => 'interest 3'],
      '#default_value' => isset($this->getValues()['interests']) ? $this->getValues()['interests'] : [],
      '#required' => FALSE,
    ];

$form['interests3'] = [
      '#type' => 'radios',
      '#title' => t('3. Nice to meet you! So, what are you interests?'),
      '#options' => [1 => 'interest 1', 2 => 'interest 2', 3 => 'interest 3'],
      '#default_value' => isset($this->getValues()['interests']) ? $this->getValues()['interests'] : [],
      '#required' => FALSE,
    ];

$form['interests4'] = [
      '#type' => 'radios',
      '#title' => t('4. Nice to meet you! So, what are you interests?'),
      '#options' => [1 => 'interest 1', 2 => 'interest 2', 3 => 'interest 3'],
      '#default_value' => isset($this->getValues()['interests']) ? $this->getValues()['interests'] : [],
      '#required' => FALSE,
    ];
    $form['interests5'] = [
      '#type' => 'radios',
      '#title' => t('5. Nice to meet you! So, what are you interests?'),
      '#options' => [1 => 'interest 1', 2 => 'interest 2', 3 => 'interest 3'],
      '#default_value' => isset($this->getValues()['interests']) ? $this->getValues()['interests'] : [],
      '#required' => FALSE,
    ];


   /* //this textfield will only be shown when the option 'Other'
    //is selected from the radios above.
    $form['custom_colour'] = [
      '#type' => 'textfield',
      '#size' => '60',
      '#placeholder' => 'Enter favourite colour',
      '#attributes' => [
        'id' => 'custom-colour',
      ],
      '#states' => [
        //show this textfield only if the radio 'other' is selected above
        'visible' => [
          //don't mistake :input for the type of field. You'll always use
          //:input here, no matter whether your source is a select, radio or checkbox element.
          ':input[name="field_select_colour"]' => ['value' => 'other'],
        ],
      ],
    ];*/

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldNames() {
    return [
      'interests',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFieldsValidators() {
    return [
      'interests' => [
        new ValidatorRequired("It would be a lot easier for me if you could fill out some of your interests."),
      ],
    ];
  }

}
