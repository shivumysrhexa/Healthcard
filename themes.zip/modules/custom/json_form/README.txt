
JSON Forms allows you to generate HTML forms from JSON Schemas using JSON Forms
(https://github.com/brutusin/json-forms) library.

These forms values will be translated to string and saved into a
long text plain field type.

You only need to configure the widget with the desired form structure and the
 default value (if needed).

Usage examples here (http://brutusin.org/json-forms/)

INSTALLATION:
1. Download module and enable.
2. Donwload library (https://github.com/brutusin/json-forms/archive/master.zip)
and place in: libraries/json-forms

CONFIGURATION:
1. Create a field of type long text plain.
2. Configure widget into "Manage form display".
