function myFunction() {
     Webcam.set({
        width: 300,
        height: 280,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
    Webcam.attach( '#my_camera' );
}
function takeSnapshot() {
    Webcam.snap( function(data_uri) {
        jQuery(".image-tag").val(data_uri);
        document.getElementById('results').innerHTML = '<img src="'+data_uri+'"/>';
    } );
}
jQuery(document).ready(function (e) {
    jQuery('#upload').on('click', function () {
          var someimage = document.getElementById('results');
                    var myimg = someimage.getElementsByTagName('img')[0];
                    var mysrc = myimg.src;
      console.log(mysrc);
        jQuery.ajax({
               /* url: 'http://127.0.0.1/healthcard/web/uploads.php', // point to server-side controller method
                dataType: 'text', // what to expect back from the server
                cache: false,
                contentType: false,
                processData: false,
                data: mysrc,*/
                type: 'POST',
                url: 'http://127.0.0.1/uploads/',
                data: '{ "imageData" : "' + mysrc + '" }',
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                success: function () {
                    alert("success");
                    //$('#msg').html(response); // display success response from the server
                },
                error: function (response) {
                 //   $('#msg').html(response); // display error response from the server
                }
            });


    });
});