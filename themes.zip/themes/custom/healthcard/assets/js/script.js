jQuery(document).ready(function() {
	if (jQuery('#user_login_popup').length > 0) {
		jQuery('#user_login_popup').modal('show');
	}
	jQuery('.user-right-container form .form-item').each(function() {
		label = jQuery(this).find('label').text();
		jQuery(this).find('input').attr('placeholder', label.trim());
	});
});